import serial
from datetime import datetime
#import datetime
import os
import time
import csv


# Function uses retry logic to open the serial port. Exits program if port
# cannot be opened.
def openSerialPort(port, baudRate, maxAttempts=5, retryInterval=2):
   attempts = 0
   while attempts < maxAttempts:
      try:
         ser = serial.Serial(port, baudRate)
         return ser
      except serial.SerialException:
         print(f"Failed to open serial port. Retrying in {retryInterval} seconds...")
         attempts += 1
         time.sleep(retryInterval)
   print(f"Error: Failed to open serial port after {maxAttempts} attempts. Exiting program.")
   exit(1)


# Open serial port.
ser = openSerialPort('COM3', 9600)


# Generate unique file name.
# timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
folderPath = 'logs'
fileName = f"data_log_{timestamp}.csv"
filePath = os.path.join(folderPath, fileName)


# Text file format.
# Open file in write mode. 
# with open(filePath, 'w') as file:
#    try:
#       while True:
#          # Read serial data from microcontroller.
#          data = ser.readline().decode('ascii', errors='ignore').strip()
# 
#          # Get current timestamp.
#          # timestampLog = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#          timestampLog = str(datetime.now())
#          
#          # Write timestamp and data to log file.
#          file.write(f'{timestampLog}: {data}\n')
# 
#          # Flush the buffer to ensure data is written immediately.
#          file.flush()

# CSV format.
# Open CSV file in write mode.
with open(filePath, 'w', newline='') as csvfile:
   csvwriter = csv.writer(csvfile)
   
   # Write the header row.
   csvwriter.writerow(['Time_stamp', 'Event', 'Ardn_time[ms]', 'ADC[0-1023]', 'SiPM[mV]', 'Deadtime[ms]', 'Temp[C]'])
   
   try:
       while True:
           # Read serial data from microcontroller.
           raw_data = ser.readline().decode('ascii', errors='ignore').strip()
           
           # Split data, assuming space separation.
           split_data = raw_data.split()
           
           # Extract data elements.
           if len(split_data) == 6:
               event, ardn_time, adc, sipm, deadtime, temp = split_data[0:]
               
               # Get current timestamp.
               timestampLog = str(datetime.now())
               
               # Write timestamp and data to the CSV file.
               csvwriter.writerow([timestampLog, event, ardn_time, adc, sipm, deadtime, temp])
               
               # Flush the buffer to ensure data is written immediately.
               csvfile.flush()

   # Break out of loop if communication with microcontroller is lost.
   except serial.SerialException:
      print("Error: Communication with the microcontroller has been interrupted.")

   except KeyboardInterrupt:
      print("Program interrupted by user.")

   # Close the file.
   finally:
      csvfile.close()





















