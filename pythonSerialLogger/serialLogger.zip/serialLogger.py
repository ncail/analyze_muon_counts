import serial
import datetime
import os
import time


# Function uses retry logic to open the serial port. Exits program if port
# cannot be opened.
def openSerialPort(port, baudRate, maxAttempts=5, retryInterval=2):
   attempts = 0
   while attempts < maxAttempts:
      try:
         ser = serial.Serial(port, baudRate)
         return ser
      except serial.SerialException:
         print(f"Failed to open serial port. Retrying in {retryInterval} seconds...")
         attempts += 1
         time.sleep(retryInterval)
   print(f"Error: Failed to open serial port after {maxAttempts} attempts. Exiting program.")
   exit(1)


# Open serial port.
ser = openSerialPort('COM3', 9600)


# Generate unique file name.
timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
folderPath = 'c:\data\muonDetector\logs-SDCard'
fileName = f"data_log_{timestamp}.txt"
filePath = os.path.join(folderPath, fileName)


# Open file in write mode. 
with open(filePath, 'w') as file:
   try:
      while True:
         # Read serial data from microcontroller.
         data = ser.readline().decode('ascii', errors='ignore').strip()

         # Get current timestamp.
         timestampLog = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
         
         # Write timestamp and data to log file.
         file.write(f'{timestampLog}: {data}\n')

         # Flush the buffer to ensure data is written immediately.
         file.flush()

   # Break out of loop if communication with microcontroller is lost.
   except serial.SerialException:
      print("Error: Communication with the microcontroller has been interrupted.")

   except KeyboardInterrupt:
      print("Program interrupted by user.")

   # Close the file.
   finally:
      file.close()





















